window._config = {
    cognito: {
        userPoolId: 'sa-east-1_wzkpdlOcg', // e.g. us-east-2_uXboG5pAb
        userPoolClientId: '4j3hf9ouu2thgs0jlk7h35tdbl', // e.g. 25ddkmj4v6hfsfvruhpfi7n4hv
        region: 'sa-east-1' // e.g. us-east-2
    },
    api: {
        invokeUrl: 'https://an2eirbqsk.execute-api.sa-east-1.amazonaws.com/prod' // e.g. https://rc7nyt4tql.execute-api.us-west-2.amazonaws.com/prod',
    }
};
